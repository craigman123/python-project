    AUTO KEY CLICKER
=========================

AutoKeyClicker is a small program that I wrote when I was bored, which inputs the specified keystrokes at the specified rate. It should support all the keys on a standard keyboard.

HOW-TO
======

The program defaults at a speed of one click per second. Enter the required text, with function keys and such added through the commands in the Help menu. On use, to change these, just type the required key into the key pressed: box, and click Set Key. You can change the interval by setting the desired interval in the box and clicking the Set Interval button. You can also toggle confirmation alerts with a checkbox in the bottom right. To begin the clicking, just click Start, or hit F3. To stop it, click Stop, or hit F4. AutoKeyClicker uses the SendKeys() function from Visual Basic, so it should be able to send any text plus codes from http://msdn.microsoft.com/en-us/library/fx2k26ca(v=vs.90).aspx .To change the hotkeys, click the Change Hotkeys option in the File menu.


UPDATE HISTORY
==============
Version 1.2.4
Fixed inability to send a single space
Fixed jank settings saving code
Moved settings file into same folder as application for convenience
Various other bug fixes

Version 1.2.3
Added the capability to perform mouse clicks while sending keystrokes.
Interface modified to add two checkboxes for left and right mouse buttons.

Version 1.2.2
Updated the help screen for the new method of entering keys.
Set the default buttons for the help and key change screens.

Version 1.2.1
Bug fixes. VB.NET complains if I try to create a file in a non-existent folder.

Version 1.2
Fixed changing of Start/stophotkeys
Allowed input of multiple keys
Optimized code for faster key input
Added saving to keep your settings on next startup. Program saves into AppData\local\lolStudios\AutoKeyClicker folder

Version 1.1
Enabled changing of Start/Stop hotkeys.

Version: 1.0.3
Support for the shift-ed versions of most keys. Checkbox added for those who prefer confirmation of a successful key or interval change.

Version 1.0.2
Fixed the Start and stop function keys not working if the program wasn't in focus

Version 1.0.1:
Bug fixed where the Mouse Left and Mouse Right options would return a wrong key error.

Version 1.0:
First iteration of the program. Interface designed, and code written. 